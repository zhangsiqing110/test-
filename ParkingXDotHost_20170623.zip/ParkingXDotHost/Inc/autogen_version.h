/*
 * This is automatically generate file, do not edit directly
 * use mkver.sh to generate this file
 * see pni_version/README.md for more information
 */
 #ifndef PNI_AUTO_VERSION_H
#define PNI_AUTO_VERSION_H
#define HOST_REL_MAJOR   0
#define HOST_REL_MINOR   3
#define HOST_REL_PATCH   53
#define HOST_REL_OTHER  
#define HOST_REL_BUILD    215
#endif
