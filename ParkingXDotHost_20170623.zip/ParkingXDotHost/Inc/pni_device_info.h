#ifndef PNI_DEVICE_INFO_H
#define PNI_DEVICE_INFO_H

#include "radio.h"

typedef struct pni_device_info {
    PNI_RadioDeviceId radio_id;
} PNI_DeviceInfo;

#endif /* PNI_DEVICE_INFO_H */
